(function () {
    'use strict';
 
    myModule
        .controller('MainController', MainController);
 
    MainController.$inject = ['$scope', '$rootScope'];
    function MainController($scope, $rootScope) {
        var vm = this;
 
        vm.message = 'Welcome';
 
        (function initController() {
        	
            $rootScope.selectedItems = [];
            $rootScope.showAll = false;
        })();
 
    }
 
})();